class Command{ //Commandパターン
    constructor(){
        this.game = this.game;
    }

    excute(){ //操作を実行
        throw new Error("Execute method must be implemented.");
    }
}